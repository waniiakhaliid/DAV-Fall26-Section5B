/* Lab Manual 10 — Air Quality 2025 time series charts */

const parseDate = d3.timeParse("%Y-%m-%d");
const formatDate = d3.timeFormat("%d %b %Y");
const formatMonth = d3.timeFormat("%b");
const WHO_GUIDELINE = 15;
const WHO_INTERIM = 75;

const monthNames = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
const weekdayOrder = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const weekdayFull = {
  Mon: "Monday", Tue: "Tuesday", Wed: "Wednesday",
  Thu: "Thursday", Fri: "Friday", Sat: "Saturday", Sun: "Sunday"
};

function levelOf(v) {
  if (v <= 35) return "Low";
  if (v <= 75) return "Moderate";
  if (v <= 150) return "High";
  return "Severe";
}

function marginConvention(svgId, width, height, margin) {
  const svg = d3.select(svgId)
    .attr("viewBox", `0 0 ${width} ${height}`)
    .attr("preserveAspectRatio", "xMidYMid meet");
  svg.selectAll("*").remove();
  const g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);
  return {
    svg,
    g,
    innerWidth: width - margin.left - margin.right,
    innerHeight: height - margin.top - margin.bottom
  };
}

/** Split sorted daily rows into contiguous segments (calendar gaps break the line). */
function contiguousSegments(rows) {
  if (!rows.length) return [];
  const segments = [[rows[0]]];
  for (let i = 1; i < rows.length; i++) {
    const gap = d3.timeDay.count(rows[i - 1].date, rows[i].date);
    if (gap === 1) segments[segments.length - 1].push(rows[i]);
    else segments.push([rows[i]]);
  }
  return segments;
}

function drawBrokenLine(g, rows, x, y, valueKey, style) {
  const gen = d3.line()
    .x((d) => x(d.date))
    .y((d) => y(d[valueKey]));
  contiguousSegments(rows).forEach((seg) => {
    g.append("path")
      .datum(seg)
      .attr("fill", "none")
      .attr("stroke", style.stroke)
      .attr("stroke-width", style.width || 1.4)
      .attr("opacity", style.opacity == null ? 1 : style.opacity)
      .attr("d", gen);
  });
}

function drawBrokenMA(g, rows, x, y, style) {
  const gen = d3.line()
    .defined((d) => d.ma7 != null)
    .x((d) => x(d.date))
    .y((d) => y(d.ma7));
  contiguousSegments(rows).forEach((seg) => {
    g.append("path")
      .datum(seg)
      .attr("fill", "none")
      .attr("stroke", style.stroke)
      .attr("stroke-width", style.width || 2.4)
      .attr("d", gen);
  });
}

d3.csv("air_quality_2025.csv").then((raw) => {
  const data = raw
    .map((d) => ({
      date: parseDate(String(d.date).trim()),
      pm25_city: +d.pm25_city,
      pm25_suburb: +d.pm25_suburb,
      temp_c: +d.temp_c
    }))
    .filter((d) => d.date && !Number.isNaN(d.pm25_city))
    .sort((a, b) => a.date - b.date);

  // ---------- Task 1 ----------
  const first = data[0].date;
  const last = data[data.length - 1].date;
  const daysIn2025 = 365;
  const allDays = d3.timeDays(new Date(2025, 0, 1), new Date(2026, 0, 1));
  const present = new Set(data.map((d) => +d.date));
  const missingDates = allDays.filter((d) => !present.has(+d));
  const gapStart = missingDates[0];
  const gapEnd = missingDates[missingDates.length - 1];

  d3.select("#task1-stats").html(`
    <p><strong>Rows:</strong> ${data.length}</p>
    <p><strong>First date:</strong> ${formatDate(first)} &nbsp;|&nbsp;
       <strong>Last date:</strong> ${formatDate(last)}</p>
    <p>2025 has <strong>${daysIn2025}</strong> days, but the file has only
       <strong>${data.length}</strong> rows — <strong>${missingDates.length}</strong>
       days are missing (12–20 Mar 2025). Order and gaps matter for time series.</p>
  `);

  // ---------- Shared helpers ----------
  const above15 = data.filter((d) => d.pm25_city > WHO_GUIDELINE).length;
  const above75 = data.filter((d) => d.pm25_city > WHO_INTERIM).length;
  const top2 = [...data].sort((a, b) => b.pm25_city - a.pm25_city).slice(0, 2);

  data.forEach((d, i) => {
    d.unhealthy = d.pm25_city > WHO_INTERIM ? 1 : 0;
    d.cumUnhealthy = (i === 0 ? 0 : data[i - 1].cumUnhealthy) + d.unhealthy;
    d.level = levelOf(d.pm25_city);
    d.month = d.date.getMonth(); // 0–11
    d.dow = weekdayOrder[(d.date.getDay() + 6) % 7]; // Mon..Sun
  });

  // 7-day moving average — each day with previous six; never average across a calendar gap
  data.forEach((d, i) => {
    if (i < 6) {
      d.ma7 = null;
      return;
    }
    let ok = true;
    for (let k = i - 5; k <= i; k++) {
      if (d3.timeDay.count(data[k - 1].date, data[k].date) !== 1) ok = false;
    }
    d.ma7 = ok ? d3.mean(data.slice(i - 6, i + 1), (x) => x.pm25_city) : null;
  });

  drawTask2(data, above15, above75, top2);
  drawTask3(data);
  drawTask4(data);
  drawTask5(data);
  drawTask6(data);
  drawTask7(data);
  drawTask8(data, missingDates, gapStart, gapEnd);
  drawTask9(data);
  writeDirectorAnswers(data, above15, above75, top2, missingDates);
}).catch((err) => {
  console.error(err);
  d3.select("body").append("p")
    .style("color", "crimson")
    .text("Could not load air_quality_2025.csv. Serve this folder with Live Server (or any local HTTP server).");
});

// ===================== TASK 2 =====================
function drawTask2(data, above15, above75, top2) {
  d3.select("#task2-title").html(
    `Task 2 — City centre PM2.5 through the year<br>
     <span style="font-size:0.85rem;font-weight:500;color:#5b6775">
       Days above 15 µg/m³: <strong>${above15}</strong> &nbsp;|&nbsp;
       Days above 75 µg/m³: <strong>${above75}</strong>
     </span>`
  );

  const margin = { top: 24, right: 40, bottom: 40, left: 52 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart2", 1000, 360, margin);

  const x = d3.scaleTime().domain(d3.extent(data, (d) => d.date)).range([0, w]);
  const y = d3.scaleLinear().domain([0, d3.max(data, (d) => d.pm25_city) * 1.08]).nice().range([h, 0]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b")));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));
  g.append("text").attr("x", -h / 2).attr("y", -38).attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle").attr("fill", "#5b6775").attr("font-size", 12)
    .text("PM2.5 (µg/m³)");

  drawBrokenLine(g, data, x, y, "pm25_city", { stroke: "#c0392b", width: 1.4 });

  // reference lines
  [
    { v: WHO_GUIDELINE, label: "WHO 15", color: "#1e8449" },
    { v: WHO_INTERIM, label: "Interim 75", color: "#b9770e" }
  ].forEach((r) => {
    g.append("line").attr("class", "ref-line")
      .attr("x1", 0).attr("x2", w).attr("y1", y(r.v)).attr("y2", y(r.v))
      .attr("stroke", r.color);
    g.append("text").attr("x", w - 4).attr("y", y(r.v) - 4)
      .attr("text-anchor", "end").attr("fill", r.color).attr("font-size", 11)
      .text(r.label);
  });

  // top 2 markers
  top2.forEach((d) => {
    g.append("circle").attr("cx", x(d.date)).attr("cy", y(d.pm25_city))
      .attr("r", 5).attr("fill", "#1c2430");
    g.append("text").attr("x", x(d.date) + 8).attr("y", y(d.pm25_city) - 8)
      .attr("font-size", 11).attr("fill", "#1c2430")
      .text(`${formatDate(d.date)}: ${d.pm25_city}`);
  });
}

// ===================== TASK 3 =====================
function drawTask3(data) {
  const margin = { top: 20, right: 30, bottom: 40, left: 52 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart3", 1000, 320, margin);

  const x = d3.scaleTime().domain(d3.extent(data, (d) => d.date)).range([0, w]);
  const y = d3.scaleLinear().domain([0, d3.max(data, (d) => d.cumUnhealthy)]).nice().range([h, 0]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b")));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));
  g.append("text").attr("x", -h / 2).attr("y", -38).attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle").attr("fill", "#5b6775").attr("font-size", 12)
    .text("Running total of days > 75");

  const area = d3.area()
    .x((d) => x(d.date))
    .y0(h)
    .y1((d) => y(d.cumUnhealthy));

  g.append("path").datum(data)
    .attr("fill", "#e59866").attr("opacity", 0.85).attr("d", area);

  g.append("path").datum(data)
    .attr("fill", "none").attr("stroke", "#a04000").attr("stroke-width", 1.5)
    .attr("d", d3.line().x((d) => x(d.date)).y((d) => y(d.cumUnhealthy)));

  const last = data[data.length - 1];
  g.append("text").attr("x", x(last.date) - 6).attr("y", y(last.cumUnhealthy) - 8)
    .attr("text-anchor", "end").attr("font-size", 12).attr("fill", "#a04000")
    .text(`Final: ${last.cumUnhealthy} (matches Task 2)`);
}

// ===================== TASK 4 =====================
function drawTask4(data) {
  const margin = { top: 28, right: 30, bottom: 40, left: 52 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart4", 1000, 340, margin);

  const x = d3.scaleTime().domain(d3.extent(data, (d) => d.date)).range([0, w]);
  const yMax = d3.max(data, (d) => Math.max(d.pm25_city, d.pm25_suburb));
  const y = d3.scaleLinear().domain([0, yMax * 1.05]).nice().range([h, 0]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b")));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));

  drawBrokenLine(g, data, x, y, "pm25_city", { stroke: "#c0392b", width: 1.4 });
  drawBrokenLine(g, data, x, y, "pm25_suburb", { stroke: "#2471a3", width: 1.4 });

  const legend = g.append("g").attr("class", "legend").attr("transform", `translate(${w - 160},0)`);
  [
    { c: "#c0392b", t: "City centre" },
    { c: "#2471a3", t: "Suburb" }
  ].forEach((item, i) => {
    legend.append("line").attr("x1", 0).attr("x2", 22).attr("y1", i * 18).attr("y2", i * 18)
      .attr("stroke", item.c).attr("stroke-width", 2.5);
    legend.append("text").attr("x", 28).attr("y", i * 18 + 4).text(item.t);
  });
}

// ===================== TASK 5 =====================
function drawTask5(data) {
  const levels = ["Low", "Moderate", "High", "Severe"];
  const colors = d3.scaleOrdinal()
    .domain(levels)
    .range(["#d5f5e3", "#f9e79f", "#f5b041", "#922b21"]);

  const byMonth = d3.rollup(
    data,
    (v) => {
      const counts = Object.fromEntries(levels.map((l) => [l, 0]));
      v.forEach((d) => { counts[d.level] += 1; });
      return counts;
    },
    (d) => d.month
  );

  const stackedData = d3.range(12).map((m) => {
    const c = byMonth.get(m) || Object.fromEntries(levels.map((l) => [l, 0]));
    return { month: m, ...c, total: d3.sum(levels, (l) => c[l]) };
  });

  d3.select("#task5-note").text(
    `Some months are shorter because of the sensor gap (March has only ${stackedData[2].total} days) ` +
    `and calendar length (Feb has 28). Stacks add up to the recorded days in each month.`
  );

  const margin = { top: 20, right: 140, bottom: 40, left: 48 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart5", 1000, 340, margin);

  const x = d3.scaleBand().domain(d3.range(12)).range([0, w]).padding(0.2);
  const y = d3.scaleLinear().domain([0, 31]).nice().range([h, 0]);

  const stack = d3.stack().keys(levels);
  const series = stack(stackedData);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).tickFormat((i) => monthNames[i]));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));
  g.append("text").attr("x", -h / 2).attr("y", -34).attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle").attr("fill", "#5b6775").attr("font-size", 12)
    .text("Days");

  g.selectAll("g.layer")
    .data(series)
    .join("g")
    .attr("class", "layer")
    .attr("fill", (d) => colors(d.key))
    .selectAll("rect")
    .data((d) => d)
    .join("rect")
    .attr("x", (d) => x(d.data.month))
    .attr("y", (d) => y(d[1]))
    .attr("height", (d) => Math.max(0, y(d[0]) - y(d[1])))
    .attr("width", x.bandwidth());

  const legend = g.append("g").attr("class", "legend").attr("transform", `translate(${w + 16}, 8)`);
  levels.forEach((l, i) => {
    legend.append("rect").attr("x", 0).attr("y", i * 22).attr("width", 14).attr("height", 14)
      .attr("fill", colors(l));
    legend.append("text").attr("x", 20).attr("y", i * 22 + 12).text(l);
  });
}

// ===================== TASK 6 =====================
function drawTask6(data) {
  const nest = d3.rollup(
    data,
    (v) => d3.mean(v, (d) => d.pm25_city),
    (d) => d.month,
    (d) => d.dow
  );

  const cells = [];
  for (let m = 0; m < 12; m++) {
    weekdayOrder.forEach((dow) => {
      const short = dow;
      // d3 %a gives Mon, Tue... matching weekdayOrder
      const val = nest.get(m)?.get(short);
      cells.push({ month: m, dow: short, value: val ?? null });
    });
  }

  const margin = { top: 30, right: 80, bottom: 40, left: 56 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart6", 1000, 380, margin);

  const x = d3.scaleBand().domain(weekdayOrder).range([0, w]).padding(0.08);
  const y = d3.scaleBand().domain(d3.range(12)).range([0, h]).padding(0.08);
  const color = d3.scaleSequential(d3.interpolateYlOrRd)
    .domain([0, d3.max(cells, (d) => d.value) || 1]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x));
  g.append("g").attr("class", "axis")
    .call(d3.axisLeft(y).tickFormat((i) => monthNames[i]));

  g.selectAll("rect.cell")
    .data(cells.filter((d) => d.value != null))
    .join("rect")
    .attr("class", "cell")
    .attr("x", (d) => x(d.dow))
    .attr("y", (d) => y(d.month))
    .attr("width", x.bandwidth())
    .attr("height", y.bandwidth())
    .attr("fill", (d) => color(d.value))
    .append("title")
    .text((d) => `${monthNames[d.month]} ${d.dow}: ${d.value.toFixed(1)}`);

  // colour legend
  const legendH = h;
  const legendW = 14;
  const legendScale = d3.scaleLinear().domain(color.domain()).range([legendH, 0]);
  const legendAxis = d3.axisRight(legendScale).ticks(6);
  const defs = g.append("defs");
  const grad = defs.append("linearGradient").attr("id", "heatGrad")
    .attr("x1", "0%").attr("y1", "100%").attr("x2", "0%").attr("y2", "0%");
  d3.range(0, 1.01, 0.1).forEach((t) => {
    grad.append("stop").attr("offset", `${t * 100}%`)
      .attr("stop-color", color(color.domain()[0] + t * (color.domain()[1] - color.domain()[0])));
  });
  const lg = g.append("g").attr("transform", `translate(${w + 18},0)`);
  lg.append("rect").attr("width", legendW).attr("height", legendH).attr("fill", "url(#heatGrad)");
  lg.append("g").attr("class", "axis").attr("transform", `translate(${legendW},0)`).call(legendAxis);
  lg.append("text").attr("x", -4).attr("y", -10).attr("font-size", 11).attr("fill", "#5b6775")
    .text("µg/m³");
}

// ===================== TASK 7 =====================
function drawTask7(data) {
  const monthly = d3.range(12).map((m) => {
    const vals = data.filter((d) => d.month === m).map((d) => d.pm25_city);
    return {
      month: m,
      min: d3.min(vals),
      max: d3.max(vals),
      mean: d3.mean(vals)
    };
  }).filter((d) => d.mean != null);

  const margin = { top: 20, right: 30, bottom: 40, left: 52 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart7", 1000, 340, margin);

  const x = d3.scalePoint().domain(monthly.map((d) => d.month)).range([0, w]).padding(0.4);
  const y = d3.scaleLinear()
    .domain([0, d3.max(monthly, (d) => d.max) * 1.05]).nice().range([h, 0]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).tickFormat((i) => monthNames[i]));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));

  const area = d3.area()
    .x((d) => x(d.month))
    .y0((d) => y(d.min))
    .y1((d) => y(d.max));

  g.append("path").datum(monthly)
    .attr("fill", "#aed6f1").attr("opacity", 0.9).attr("d", area);

  g.append("path").datum(monthly)
    .attr("fill", "none").attr("stroke", "#1a5276").attr("stroke-width", 2.2)
    .attr("d", d3.line().x((d) => x(d.month)).y((d) => y(d.mean)));

  g.selectAll("circle.mean")
    .data(monthly)
    .join("circle")
    .attr("cx", (d) => x(d.month))
    .attr("cy", (d) => y(d.mean))
    .attr("r", 3.5)
    .attr("fill", "#1a5276");
}

// ===================== TASK 8 =====================
function drawTask8(data, missingDates, gapStart, gapEnd) {
  const margin = { top: 28, right: 30, bottom: 40, left: 52 };
  const { g, innerWidth: w, innerHeight: h } = marginConvention("#chart8", 1000, 360, margin);

  const x = d3.scaleTime().domain(d3.extent(data, (d) => d.date)).range([0, w]);
  const y = d3.scaleLinear().domain([0, d3.max(data, (d) => d.pm25_city) * 1.05]).nice().range([h, 0]);

  g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`)
    .call(d3.axisBottom(x).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b")));
  g.append("g").attr("class", "axis").call(d3.axisLeft(y));

  // shade gap
  if (gapStart && gapEnd) {
    const x0 = x(gapStart);
    const x1 = x(d3.timeDay.offset(gapEnd, 1));
    g.append("rect")
      .attr("x", x0).attr("y", 0)
      .attr("width", Math.max(0, x1 - x0)).attr("height", h)
      .attr("fill", "#f5cba7").attr("opacity", 0.65);
    g.append("text")
      .attr("x", (x0 + x1) / 2).attr("y", 16)
      .attr("text-anchor", "middle").attr("font-size", 11).attr("fill", "#6e2c00")
      .text("No data: sensor offline");
  }

  drawBrokenLine(g, data, x, y, "pm25_city", { stroke: "#c0392b", width: 1, opacity: 0.35 });
  drawBrokenMA(g, data, x, y, { stroke: "#1c2430", width: 2.4 });

  g.append("text")
    .attr("x", w).attr("y", h + 32)
    .attr("text-anchor", "end").attr("font-size", 12).attr("fill", "#6e2c00")
    .text(`Missing days: ${missingDates.length} (12–20 Mar 2025)`);

  const legend = g.append("g").attr("class", "legend").attr("transform", "translate(8,0)");
  legend.append("line").attr("x1", 0).attr("x2", 22).attr("y1", 0).attr("y2", 0)
    .attr("stroke", "#c0392b").attr("opacity", 0.35).attr("stroke-width", 2);
  legend.append("text").attr("x", 28).attr("y", 4).text("Daily");
  legend.append("line").attr("x1", 90).attr("x2", 112).attr("y1", 0).attr("y2", 0)
    .attr("stroke", "#1c2430").attr("stroke-width", 2.5);
  legend.append("text").attr("x", 118).attr("y", 4).text("7-day average");
}

// ===================== TASK 9 =====================
function drawTask9(data) {
  const marginMain = { top: 16, right: 30, bottom: 30, left: 52 };
  const marginBrush = { top: 8, right: 30, bottom: 24, left: 52 };
  const width = 1000;
  const heightMain = 280;
  const heightBrush = 90;

  const main = marginConvention("#chart9-main", width, heightMain, marginMain);
  const brushChart = marginConvention("#chart9-brush", width, heightBrush, marginBrush);

  const fullDomain = d3.extent(data, (d) => d.date);
  const yMax = d3.max(data, (d) => d.pm25_city);

  const xMain = d3.scaleTime().domain(fullDomain).range([0, main.innerWidth]);
  const yMain = d3.scaleLinear().domain([0, yMax * 1.05]).nice().range([main.innerHeight, 0]);
  const xBrush = d3.scaleTime().domain(fullDomain).range([0, brushChart.innerWidth]);
  const yBrush = d3.scaleLinear().domain([0, yMax]).range([brushChart.innerHeight, 0]);

  const xAxisMain = main.g.append("g").attr("class", "axis")
    .attr("transform", `translate(0,${main.innerHeight})`);
  main.g.append("g").attr("class", "axis").call(d3.axisLeft(yMain));

  const mainLines = main.g.append("g").attr("class", "main-lines");

  function updateMain(domain) {
    xMain.domain(domain);
    xAxisMain.call(d3.axisBottom(xMain).ticks(8).tickFormat(d3.timeFormat("%d %b")));
    mainLines.selectAll("*").remove();
    const visible = data.filter((d) => d.date >= domain[0] && d.date <= domain[1]);
    drawBrokenLine(mainLines, visible, xMain, yMain, "pm25_city", { stroke: "#c0392b", width: 1.5 });
  }
  updateMain(fullDomain);

  // overview
  brushChart.g.append("g").attr("class", "axis")
    .attr("transform", `translate(0,${brushChart.innerHeight})`)
    .call(d3.axisBottom(xBrush).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b")));

  drawBrokenLine(brushChart.g, data, xBrush, yBrush, "pm25_city", {
    stroke: "#c0392b", width: 1, opacity: 0.7
  });

  const brush = d3.brushX()
    .extent([[0, 0], [brushChart.innerWidth, brushChart.innerHeight]])
    .on("brush end", (event) => {
      if (!event.selection) {
        if (event.type === "end") updateMain(fullDomain);
        return;
      }
      const [x0, x1] = event.selection.map(xBrush.invert);
      updateMain([x0, x1]);
    });

  const brushG = brushChart.g.append("g").attr("class", "brush").call(brush);

  d3.select("#reset-zoom").on("click", () => {
    brushG.call(brush.move, null);
    updateMain(fullDomain);
  });
}

// ===================== DIRECTOR Q&A =====================
function writeDirectorAnswers(data, above15, above75, top2, missingDates) {
  const monthlyMean = d3.rollup(data, (v) => d3.mean(v, (d) => d.pm25_city), (d) => d.month);
  const means = d3.range(12).map((m) => ({ m, v: monthlyMean.get(m) })).filter((d) => d.v != null);
  const best = d3.least(means, (d) => d.v);
  const worst = d3.greatest(means, (d) => d.v);
  const ratio = worst.v / best.v;

  const monthlySpread = d3.range(12).map((m) => {
    const vals = data.filter((d) => d.month === m).map((d) => d.pm25_city);
    return { m, spread: d3.max(vals) - d3.min(vals), max: d3.max(vals), min: d3.min(vals) };
  }).filter((d) => d.spread != null && !Number.isNaN(d.spread));
  const widest = d3.greatest(monthlySpread, (d) => d.spread);

  // build-up speed: new unhealthy days per month
  const unhealthyByMonth = d3.rollup(
    data.filter((d) => d.pm25_city > WHO_INTERIM),
    (v) => v.length,
    (d) => d.month
  );
  const buildFast = d3.range(12)
    .map((m) => ({ m, n: unhealthyByMonth.get(m) || 0 }))
    .sort((a, b) => b.n - a.n);

  const severeMonths = d3.range(12).filter((m) =>
    data.some((d) => d.month === m && d.level === "Severe")
  );
  const lowByMonth = d3.rollup(
    data.filter((d) => d.level === "Low"),
    (v) => v.length,
    (d) => d.month
  );
  const mostLow = d3.greatest(
    d3.range(12).map((m) => ({ m, n: lowByMonth.get(m) || 0 })),
    (d) => d.n
  );

  // city vs suburb mean absolute difference by month
  const diffByMonth = d3.range(12).map((m) => {
    const rows = data.filter((d) => d.month === m);
    return {
      m,
      diff: d3.mean(rows, (d) => Math.abs(d.pm25_city - d.pm25_suburb))
    };
  });
  const biggestDiff = d3.greatest(diffByMonth, (d) => d.diff);

  const share15 = ((above15 / data.length) * 100).toFixed(1);
  const share75 = ((above75 / data.length) * 100).toFixed(1);

  const answers = [
    {
      q: "Seasonality — Which months are worst and best?",
      a: `Point to Task 2 / Task 7. Worst month is ${monthNames[worst.m]} (avg ~${worst.v.toFixed(0)} µg/m³); best is ${monthNames[best.m]} (avg ~${best.v.toFixed(0)} µg/m³). Worst is about <strong>${ratio.toFixed(1)}×</strong> the best.`
    },
    {
      q: "Anomalies — The two highest days?",
      a: `Point to Task 2 markers: <strong>${formatDate(top2[0].date)}</strong> (${top2[0].pm25_city}) and <strong>${formatDate(top2[1].date)}</strong> (${top2[1].pm25_city}). Nov 8 sits in the winter smog season; May 18 is an isolated spike outside the usual winter peak — could be a dust storm, fire, or local event.`
    },
    {
      q: "Guideline — Days above 15 and 75?",
      a: `Point to Task 2 title counts: <strong>${above15}</strong> days above 15 (${share15}% of ${data.length} recorded days) and <strong>${above75}</strong> days above 75 (${share75}%).`
    },
    {
      q: "Build-up — When do unhealthy days accumulate fastest?",
      a: `Point to Task 3 area chart. Fastest build-up in <strong>${monthNames[buildFast[0].m]}</strong>, <strong>${monthNames[buildFast[1].m]}</strong> and <strong>${monthNames[buildFast[2].m]}</strong> (${buildFast[0].n}, ${buildFast[1].n}, ${buildFast[2].n} unhealthy days). The curve goes flat in summer (Jun–Aug: almost no new days above 75).`
    },
    {
      q: "Comparison — Suburb vs city?",
      a: `Point to Task 4. Suburb follows the same seasonal shape but is usually lower. They differ most around <strong>${monthNames[biggestDiff.m]}</strong> (largest average gap). Winter peaks remain high at both stations.`
    },
    {
      q: "Composition — Severe / Low months; shorter months?",
      a: `Point to Task 5. Severe days appear in ${severeMonths.map((m) => monthNames[m]).join(", ")}. Most Low days: <strong>${monthNames[mostLow.m]}</strong> (${mostLow.n}). March is short because the sensor was offline 12–20 Mar; February is short by calendar (28 days).`
    },
    {
      q: "Pattern — Day-of-week or month?",
      a: `Point to Task 6 heatmap. Colour changes strongly down the months (winter dark, summer light) and only weakly across weekdays — pollution is driven mainly by season (weather / heating / inversion), not a clear weekday traffic cycle.`
    },
    {
      q: "Spread — Widest best–worst gap?",
      a: `Point to Task 7. Widest gap is <strong>${monthNames[widest.m]}</strong> (${widest.min}–${widest.max}, spread ${widest.spread.toFixed(0)}). A monthly average hides these extremes — one severe spike can sit inside an “average” looking month.`
    },
    {
      q: "Trend and data quality?",
      a: `Point to Task 8. The thick 7-day line shows a seasonal cycle (high winter, low summer), not a steady year-long rise or fall. <strong>${missingDates.length}</strong> days are missing (12–20 Mar). Drawing an unbroken line across that gap would invent values and hide that the sensor was offline.`
    },
    {
      q: "Zoom — Month with widest spread?",
      a: `Use Task 9: brush <strong>${monthNames[widest.m]}</strong>. You can see the day-to-day spikes (including the ${widest.max} peak) that disappear when the full year is compressed.`
    },
    {
      q: "Chart choice — What a pie of monthly averages misses?",
      a: `A pie cannot show (1) <em>when</em> pollution rose or fell through the year (no time order), and (2) extremes / unhealthy-day build-up / sensor gaps — all of which Tasks 2, 3 and 8 make visible.`
    },
    {
      q: "Recommendation — Two months for school restrictions?",
      a: `Restrict in <strong>December</strong> and <strong>January</strong> (or Dec + Feb). Evidence: Task 2/7 show the highest monthly means and many days above 75; Task 3 shows rapid unhealthy-day build-up in those winter months; Task 5 shows Severe days clustered there. Summer months are mostly Low/Moderate.`
    }
  ];

  const box = d3.select("#director-answers");
  answers.forEach((item) => {
    const det = box.append("details");
    det.append("summary").text(item.q);
    det.append("p").html(item.a);
  });
}
