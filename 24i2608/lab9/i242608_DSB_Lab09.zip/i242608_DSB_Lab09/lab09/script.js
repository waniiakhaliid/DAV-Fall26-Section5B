/* Lab 9 – Hierarchies, networks and maps with D3.js
   Run through a local server (e.g. VS Code Live Server) so d3.csv / d3.json can load files. */

const DATA = {
  university: "dataset/university.csv",
  flights: "dataset/flights.csv",
  population: "dataset/population.csv",
  cities: "dataset/pakistan_cities.csv",
  world: "dataset/custom.geo.json"
};

/* ---------- shared helpers ---------- */
const tooltip = d3.select("#tooltip");
function showTip(event, html) { tooltip.html(html).style("opacity", 1); moveTip(event); }
function moveTip(event) { tooltip.style("left", (event.pageX + 14) + "px").style("top", (event.pageY + 14) + "px"); }
function hideTip() { tooltip.style("opacity", 0); }

const fmt = d3.format(",");
const DEPT_COLORS = ["#2b6cb0", "#c05621", "#2f855a", "#805ad5"];

function makeSvg(selector, w, h) {
  return d3.select(selector).append("svg").attr("viewBox", `0 0 ${w} ${h}`).attr("role", "img");
}

function addTitle(svg, w, text) {
  svg.append("text").attr("x", w / 2).attr("y", 24).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", 600).text(text);
}

/* Flat CSV rows -> {name, children:[department -> courses]} used by Tasks 1 and 2 */
function buildHierarchyData(rows) {
  return {
    name: "University",
    children: Array.from(d3.group(rows, d => d.department), ([dept, items]) => ({
      name: dept,
      children: items.map(r => ({ name: r.course, department: dept, value: r.students }))
    }))
  };
}

/* Projection shared by Tasks 5 and 6: Mercator centred on Pakistan (longitude first). */
function pakistanProjection(w, h) {
  return d3.geoMercator().center([69.5, 30.6]).scale(2300).translate([w / 2, h / 2]);
}

/* Place a city label right/left/up/down of its circle (avoids collisions between close cities). */
function placeLabel(t, x, y, rad, mode = "right") {
  if (mode === "left") t.attr("x", x - rad - 5).attr("y", y + 4).attr("text-anchor", "end");
  else if (mode === "up") t.attr("x", x).attr("y", y - rad - 6).attr("text-anchor", "middle");
  else if (mode === "down") t.attr("x", x).attr("y", y + rad + 15).attr("text-anchor", "middle");
  else t.attr("x", x + rad + 5).attr("y", y + 4).attr("text-anchor", "start");
}

/* Degree (number of routes) per city, from the edge list. */
function routeStats(flights) {
  const stats = new Map();
  const get = c => { if (!stats.has(c)) stats.set(c, { routes: 0, flights: 0 }); return stats.get(c); };
  flights.forEach(f => {
    [f.source, f.target].forEach(c => { const s = get(c); s.routes += 1; s.flights += f.flights; });
  });
  return stats;
}

/* =====================================================
   Task 1: Treemap
   ===================================================== */
async function drawTreemap() {
  const rows = await d3.csv(DATA.university, d3.autoType);
  const depts = [...new Set(rows.map(d => d.department))];
  const color = d3.scaleOrdinal().domain(depts).range(DEPT_COLORS);

  const W = 960, H = 600, top = 40;
  const svg = makeSvg("#treemap", W, H);
  addTitle(svg, W, "Course Enrollment by Department (area = number of students)");

  const root = d3.hierarchy(buildHierarchyData(rows))
    .sum(d => d.value || 0)
    .sort((a, b) => b.value - a.value);

  d3.treemap().size([W, H - top - 6])
    .paddingOuter(3)
    .paddingTop(d => d.depth === 1 ? 22 : 3)
    .paddingInner(2)
    .round(true)(root);

  const g = svg.append("g").attr("transform", `translate(0,${top})`);

  // department frames + labels
  const dept = g.selectAll("g.dept").data(root.children).join("g").attr("class", "dept");
  dept.append("rect")
    .attr("x", d => d.x0).attr("y", d => d.y0)
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0)
    .attr("fill", d => color(d.data.name)).attr("fill-opacity", 0.15)
    .attr("stroke", d => color(d.data.name)).attr("stroke-width", 1.5);
  dept.append("text")
    .attr("x", d => d.x0 + 6).attr("y", d => d.y0 + 16)
    .attr("font-size", 13).attr("font-weight", 700).attr("fill", d => color(d.data.name))
    .text(d => d.data.name);

  // course rectangles
  const leaf = g.selectAll("g.leaf").data(root.leaves()).join("g")
    .attr("class", "leaf")
    .attr("transform", d => `translate(${d.x0},${d.y0})`);

  leaf.append("clipPath").attr("id", (d, i) => `clip-${i}`)
    .append("rect").attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0);

  leaf.append("rect")
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0)
    .attr("fill", d => color(d.data.department)).attr("stroke", "#fff").attr("stroke-width", 1)
    .style("cursor", "default")
    .on("mouseover", function () { d3.select(this).attr("fill-opacity", 0.8); })
    .on("mousemove", (event, d) => showTip(event,
      `<b>${d.data.name}</b><br>Department: ${d.data.department}<br>Students: ${fmt(d.data.value)}`))
    .on("mouseout", function () { d3.select(this).attr("fill-opacity", 1); hideTip(); });

  // wrap course names onto several lines so they are not cut off (about 6.4px per character at 12px)
  function wrap(d) {
    const maxChars = Math.max(4, Math.floor((d.x1 - d.x0 - 12) / 6.4));
    const maxLines = Math.max(1, Math.floor((d.y1 - d.y0 - 24) / 15));
    const lines = []; let cur = "";
    d.data.name.split(" ").forEach(w => {
      if ((cur + " " + w).trim().length <= maxChars || !cur) cur = (cur + " " + w).trim();
      else { lines.push(cur); cur = w; }
    });
    lines.push(cur);
    return lines.slice(0, maxLines);
  }
  const label = leaf.append("text").attr("clip-path", (d, i) => `url(#clip-${i})`)
    .attr("fill", "#fff").style("pointer-events", "none");
  label.each(function (d) {
    const t = d3.select(this), lines = wrap(d);
    lines.forEach((ln, i) => t.append("tspan").attr("x", 6).attr("y", 17 + i * 15).attr("font-size", 12).attr("font-weight", 600).text(ln));
    if ((d.y1 - d.y0) > 24 + lines.length * 15 - 8)
      t.append("tspan").attr("x", 6).attr("y", 17 + lines.length * 15).attr("font-size", 11).attr("opacity", .9).text(fmt(d.data.value) + " students");
  });

  // legend for the four departments
  d3.select("#treemap-legend").selectAll("span.item").data(depts).join("span").attr("class", "item")
    .html(d => `<i style="background:${color(d)}"></i>${d}`);
}

/* =====================================================
   Task 2: Dendrogram (collapsible)
   ===================================================== */
async function drawDendrogram() {
  const rows = await d3.csv(DATA.university, d3.autoType);

  const margin = { top: 50, right: 230, bottom: 20, left: 150 };
  const W = 960, H = 680;
  const innerW = W - margin.left - margin.right, innerH = H - margin.top - margin.bottom;

  const svg = makeSvg("#dendrogram", W, H);
  addTitle(svg, W, "University Structure: Departments and Courses");
  svg.append("text").attr("x", W / 2).attr("y", 42).attr("text-anchor", "middle")
    .attr("font-size", 12).attr("fill", "#616e7c").text("Click a department to collapse or expand");
  const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
  const gLinks = g.append("g").attr("fill", "none").attr("stroke", "#9aa5b1").attr("stroke-width", 1.5);
  const gNodes = g.append("g");

  const root = d3.hierarchy(buildHierarchyData(rows));
  let uid = 0; root.eachBefore(d => { d.uid = uid++; });
  root.x0 = innerH / 2; root.y0 = 0;

  const cluster = d3.cluster().size([innerH, innerW]);
  const linkPath = d3.linkHorizontal().x(d => d.y).y(d => d.x);
  const depthColor = d3.scaleOrdinal().domain([0, 1, 2]).range(["#1f3a5f", "#c05621", "#2f855a"]);

  function update(source) {
    cluster(root);
    const nodes = root.descendants();
    // cluster() puts every leaf in the last column; keep one fixed column per depth instead
    nodes.forEach(d => { d.y = d.depth * (innerW / 2); });
    const t = svg.transition().duration(500);

    gLinks.selectAll("path").data(root.links(), d => d.target.uid).join(
      enter => enter.append("path").attr("d", () => {
        const o = { x: source.x0, y: source.y0 }; return linkPath({ source: o, target: o });
      }),
      update => update,
      exit => exit.transition(t).attr("d", () => {
        const o = { x: source.x, y: source.y }; return linkPath({ source: o, target: o });
      }).remove()
    ).transition(t).attr("d", linkPath);

    const node = gNodes.selectAll("g.node").data(nodes, d => d.uid).join(
      enter => {
        const e = enter.append("g").attr("class", "node")
          .attr("transform", `translate(${source.y0},${source.x0})`)
          .style("cursor", d => d.depth === 1 ? "pointer" : "default")
          .on("click", (event, d) => {
            if (d.depth !== 1) return;
            if (d.children) { d._children = d.children; d.children = null; }
            else { d.children = d._children; d._children = null; }
            update(d);
          })
          .on("mousemove", (event, d) => {
            const n = d.depth === 1 ? (d.children || d._children).length + " courses"
              : d.depth === 2 ? fmt(d.data.value) + " students" : (d.children.length + " departments");
            showTip(event, `<b>${d.data.name}</b><br>${n}`);
          })
          .on("mouseout", hideTip);
        e.append("circle").attr("r", 7).attr("stroke", "#fff").attr("stroke-width", 2);
        e.append("text").attr("class", "halo").attr("font-size", 12);
        return e;
      },
      update => update,
      exit => exit.transition(t).attr("transform", `translate(${source.y},${source.x})`).remove()
    );

    node.transition(t).attr("transform", d => `translate(${d.y},${d.x})`);
    node.select("circle")
      .attr("fill", d => depthColor(d.depth))
      .attr("stroke", d => d._children ? "#f6ad55" : "#fff")
      .attr("stroke-width", d => d._children ? 3 : 2);
    // leaf labels on the right, parent labels on the left (d.height is fixed, unlike d.children)
    node.select("text")
      .attr("x", d => d.height === 0 ? 12 : -12)
      .attr("dy", d => d.height === 0 ? "0.32em" : (d.depth === 0 ? "0.32em" : "-0.6em"))
      .attr("text-anchor", d => d.height === 0 ? "start" : "end")
      .attr("font-weight", d => d.height === 0 ? 400 : 600)
      .text(d => d.data.name + (d._children ? " (+" + d._children.length + ")" : ""));

    nodes.forEach(d => { d.x0 = d.x; d.y0 = d.y; });
  }
  update(root);

  const names = ["University (root)", "Department", "Course"];
  d3.select("#dendro-legend").selectAll("span.item").data([0, 1, 2]).join("span").attr("class", "item")
    .html(d => `<i style="background:${depthColor(d)};border-radius:50%"></i>${names[d]}`);
}

/* =====================================================
   Task 3: Force-directed flight network
   ===================================================== */
async function drawNetwork() {
  const flights = await d3.csv(DATA.flights, d3.autoType);

  // node list from the edge list
  const stats = routeStats(flights);
  const nodes = Array.from(new Set(flights.flatMap(d => [d.source, d.target])))
    .map(id => ({ id, degree: stats.get(id).routes, total: stats.get(id).flights }));
  const links = flights.map(d => ({ source: d.source, target: d.target, flights: d.flights }));

  const neighbors = new Map(nodes.map(n => [n.id, new Set([n.id])]));
  flights.forEach(d => { neighbors.get(d.source).add(d.target); neighbors.get(d.target).add(d.source); });

  const W = 960, H = 640;
  const svg = makeSvg("#network", W, H);
  addTitle(svg, W, "Weekly Flights Between Ten Pakistani Cities");

  const width = d3.scaleLinear().domain(d3.extent(links, d => d.flights)).range([1.5, 12]);
  const radius = d3.scaleSqrt().domain(d3.extent(nodes, d => d.degree)).range([9, 28]);

  const link = svg.append("g").attr("stroke", "#8896a8").attr("stroke-opacity", 0.6).attr("stroke-linecap", "round")
    .selectAll("line").data(links).join("line").attr("stroke-width", d => width(d.flights))
    .on("mousemove", (event, d) => showTip(event, `<b>${d.source.id} – ${d.target.id}</b><br>${d.flights} flights per week`))
    .on("mouseout", hideTip);

  const node = svg.append("g").selectAll("g").data(nodes).join("g").style("cursor", "grab");
  node.append("circle").attr("r", d => radius(d.degree)).attr("fill", "#2b6cb0").attr("stroke", "#fff").attr("stroke-width", 2);
  node.append("text").attr("class", "halo").attr("font-size", 12).attr("font-weight", 600)
    .attr("text-anchor", "middle").attr("dy", d => radius(d.degree) + 14).text(d => d.id);

  node.on("mouseover", (event, d) => {
      const near = neighbors.get(d.id);
      node.attr("opacity", n => near.has(n.id) ? 1 : 0.15);
      link.attr("stroke-opacity", l => (l.source.id === d.id || l.target.id === d.id) ? 0.95 : 0.06)
          .attr("stroke", l => (l.source.id === d.id || l.target.id === d.id) ? "#c05621" : "#8896a8");
    })
    .on("mousemove", (event, d) => showTip(event, `<b>${d.id}</b><br>${d.degree} routes<br>${d.total} flights per week`))
    .on("mouseout", () => {
      node.attr("opacity", 1);
      link.attr("stroke-opacity", 0.6).attr("stroke", "#8896a8");
      hideTip();
    });

  const sim = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(230).strength(0.35))
    .force("charge", d3.forceManyBody().strength(-1400))
    .force("center", d3.forceCenter(W / 2, H / 2 + 14))
    .force("collide", d3.forceCollide(d => radius(d.degree) + 14))
    .on("tick", () => {
      nodes.forEach(d => {
        const r = radius(d.degree) + 4;
        d.x = Math.max(r, Math.min(W - r, d.x));
        d.y = Math.max(r + 36, Math.min(H - r - 16, d.y));
      });
      link.attr("x1", d => d.source.x).attr("y1", d => d.source.y).attr("x2", d => d.target.x).attr("y2", d => d.target.y);
      node.attr("transform", d => `translate(${d.x},${d.y})`);
    });

  node.call(d3.drag()
    .on("start", (event, d) => { if (!event.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
    .on("drag", (event, d) => { d.fx = event.x; d.fy = event.y; })
    .on("end", (event, d) => { if (!event.active) sim.alphaTarget(0); d.fx = null; d.fy = null; }));
}

/* =====================================================
   Task 4: World population choropleth
   ===================================================== */
async function drawChoropleth() {
  const [world, pop] = await Promise.all([d3.json(DATA.world), d3.csv(DATA.population, d3.autoType)]);
  const popById = new Map(pop.map(d => [d.id, d]));       // join key: ISO country code
  const features = world.features.filter(f => f.properties.name !== "Antarctica");

  const W = 960, H = 560;
  const svg = makeSvg("#choropleth", W, H);
  addTitle(svg, W, "World Population by Country (millions)");

  const projection = d3.geoNaturalEarth1().fitExtent([[10, 40], [W - 10, H - 60]], { type: "FeatureCollection", features });
  const path = d3.geoPath(projection);

  const max = d3.max(pop, d => d.population_millions);
  const color = d3.scaleSequentialSqrt(t => d3.interpolateYlGnBu(0.12 + 0.88 * t)).domain([0, max]);
  const NO_DATA = "#e2e5e9";

  svg.append("g").selectAll("path").data(features).join("path")
    .attr("d", path)
    .attr("fill", d => popById.has(d.id) ? color(popById.get(d.id).population_millions) : NO_DATA)
    .attr("stroke", "#fff").attr("stroke-width", 0.5)
    .on("mouseover", function () { d3.select(this).raise().attr("stroke", "#111").attr("stroke-width", 1.6); })
    .on("mousemove", (event, d) => {
      const r = popById.get(d.id);
      showTip(event, r ? `<b>${r.country}</b><br>${fmt(r.population_millions)} million`
                       : `<b>${d.properties.name}</b><br>No data`);
    })
    .on("mouseout", function () { d3.select(this).attr("stroke", "#fff").attr("stroke-width", 0.5); hideTip(); });

  // gradient legend with minimum and maximum labels
  const lx = W / 2 - 160, ly = H - 38, lw = 320, lh = 12;
  const defs = svg.append("defs");
  const grad = defs.append("linearGradient").attr("id", "pop-gradient");
  d3.range(0, 1.001, 0.1).forEach(t => grad.append("stop").attr("offset", `${t * 100}%`).attr("stop-color", color(t * max)));
  svg.append("rect").attr("x", lx).attr("y", ly).attr("width", lw).attr("height", lh).attr("fill", "url(#pop-gradient)").attr("stroke", "#9aa5b1");
  svg.append("text").attr("x", lx).attr("y", ly + 27).attr("font-size", 12).text("0 M");
  svg.append("text").attr("x", lx + lw).attr("y", ly + 27).attr("font-size", 12).attr("text-anchor", "end").text(`${fmt(max)} M`);
  svg.append("rect").attr("x", lx + lw + 24).attr("y", ly).attr("width", 14).attr("height", lh).attr("fill", NO_DATA).attr("stroke", "#9aa5b1");
  svg.append("text").attr("x", lx + lw + 44).attr("y", ly + 10).attr("font-size", 12).text("No data");
}

/* =====================================================
   Task 5: Pakistan cities point map
   ===================================================== */
const MIN_R = 3; // tiny cities stay visible/hoverable

async function drawPointMap() {
  const [world, cities] = await Promise.all([d3.json(DATA.world), d3.csv(DATA.cities, d3.autoType)]);
  const W = 760, H = 700;
  const svg = makeSvg("#pointmap", W, H);
  addTitle(svg, W, "Largest Cities of Pakistan (circle area = population)");

  const projection = pakistanProjection(W, H);
  const path = d3.geoPath(projection);
  const r = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 36]);
  const radius = d => Math.max(MIN_R, r(d.pop));

  svg.append("g").selectAll("path").data(world.features).join("path").attr("d", path)
    .attr("fill", d => d.id === "PAK" ? "#e3ecf6" : "#f1f3f5").attr("stroke", "#aeb8c4").attr("stroke-width", d => d.id === "PAK" ? 1.2 : 0.6);

  const pts = svg.append("g").selectAll("circle").data([...cities].sort((a, b) => b.pop - a.pop)).join("circle")
    .attr("cx", d => projection([d.lon, d.lat])[0])   // longitude first
    .attr("cy", d => projection([d.lon, d.lat])[1])
    .attr("r", radius)
    .attr("fill", "#2b6cb0").attr("fill-opacity", 0.5).attr("stroke", "#1f4e85").attr("stroke-width", 1)
    .on("mouseover", function () { d3.select(this).attr("fill-opacity", 0.85).attr("stroke-width", 2); })
    .on("mousemove", (event, d) => showTip(event, `<b>${d.name}</b><br>Population: ${fmt(d.pop)}`))
    .on("mouseout", function () { d3.select(this).attr("fill-opacity", 0.5).attr("stroke-width", 1); hideTip(); });

  // labels only for cities above 1 million; close neighbours get different label positions
  const mode = { Islamabad: "up", Rawalpindi: "down", Peshawar: "left", Faisalabad: "left" };
  svg.append("g").selectAll("text").data(cities.filter(d => d.pop > 1e6)).join("text").attr("class", "halo")
    .attr("font-size", 12).attr("font-weight", 600).style("pointer-events", "none")
    .each(function (d) {
      const [x, y] = projection([d.lon, d.lat]);
      placeLabel(d3.select(this), x, y, radius(d), mode[d.name]);
      d3.select(this).text(d.name);
    });

  // size legend
  const lg = svg.append("g").attr("transform", `translate(30,70)`);
  lg.append("text").attr("font-size", 12).attr("font-weight", 600).text("Population");
  [1e6, 5e6, 15e6].forEach((v, i, arr) => {
    const cy = 100 - r(v);
    lg.append("circle").attr("cx", 36).attr("cy", cy).attr("r", r(v)).attr("fill", "none").attr("stroke", "#1f4e85");
    lg.append("text").attr("x", 36).attr("y", cy - r(v) - 3).attr("text-anchor", "middle").attr("font-size", 11).text(`${v / 1e6} M`);
  });
}

/* =====================================================
   Task 6: Combined spatial encoding map
   ===================================================== */
async function drawCombined() {
  const [world, cities, flights] = await Promise.all([
    d3.json(DATA.world), d3.csv(DATA.cities, d3.autoType), d3.csv(DATA.flights, d3.autoType)]);

  const W = 760, H = 700;
  const svg = makeSvg("#combined", W, H);
  addTitle(svg, W, "Pakistan: Cities, Population and Weekly Flights");

  const projection = pakistanProjection(W, H);
  const path = d3.geoPath(projection);
  const stats = routeStats(flights);
  const HUB_MIN = 4;
  const isHub = d => (stats.get(d.name)?.routes || 0) >= HUB_MIN;

  const cityByName = new Map(cities.map(c => [c.name, c]));
  cities.forEach(c => { [c.x, c.y] = projection([c.lon, c.lat]); });

  // match each route's source/target to city coordinates
  const routes = flights.map(f => ({ ...f, a: cityByName.get(f.source), b: cityByName.get(f.target) }))
    .filter(f => f.a && f.b);

  const r = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 30]);
  const radius = d => Math.max(MIN_R, r(d.pop));
  const lw = d3.scaleLinear().domain(d3.extent(flights, d => d.flights)).range([1, 7]);
  const color = d => isHub(d) ? "#d9480f" : "#2b6cb0";

  svg.append("g").selectAll("path").data(world.features).join("path").attr("d", path)
    .attr("fill", d => d.id === "PAK" ? "#e3ecf6" : "#f1f3f5").attr("stroke", "#aeb8c4").attr("stroke-width", d => d.id === "PAK" ? 1.2 : 0.6);

  // 1) routes first (gently curved so overlapping routes stay readable)
  const arc = d => {
    const dx = d.b.x - d.a.x, dy = d.b.y - d.a.y;
    const mx = (d.a.x + d.b.x) / 2 - dy * 0.12, my = (d.a.y + d.b.y) / 2 + dx * 0.12;
    return `M${d.a.x},${d.a.y}Q${mx},${my} ${d.b.x},${d.b.y}`;
  };
  const route = svg.append("g").attr("fill", "none").attr("stroke-linecap", "round")
    .selectAll("path").data(routes).join("path").attr("d", arc)
    .attr("stroke", "#5a6a85").attr("stroke-opacity", 0.5).attr("stroke-width", d => lw(d.flights))
    .on("mousemove", (event, d) => showTip(event, `<b>${d.source} – ${d.target}</b><br>${d.flights} flights per week`))
    .on("mouseout", hideTip);

  // 2) cities on top
  const sorted = [...cities].sort((a, b) => b.pop - a.pop);
  const dot = svg.append("g").selectAll("circle").data(sorted).join("circle")
    .attr("cx", d => d.x).attr("cy", d => d.y).attr("r", radius)
    .attr("fill", color).attr("fill-opacity", 0.7).attr("stroke", "#fff").attr("stroke-width", 1.2);

  const labeled = cities.filter(d => stats.has(d.name));
  const mode = { Faisalabad: "left", Peshawar: "left" };
  const lab = svg.append("g").selectAll("text").data(labeled).join("text").attr("class", "halo")
    .attr("font-size", 12).attr("font-weight", 600).style("pointer-events", "none")
    .each(function (d) { placeLabel(d3.select(this), d.x, d.y, radius(d), mode[d.name]); d3.select(this).text(d.name); });

  const connected = new Map(cities.map(c => [c.name, new Set([c.name])]));
  routes.forEach(f => { connected.get(f.source).add(f.target); connected.get(f.target).add(f.source); });

  dot.on("mouseover", (event, d) => {
      const near = connected.get(d.name);
      route.attr("stroke-opacity", f => (f.source === d.name || f.target === d.name) ? 0.95 : 0.06)
           .attr("stroke", f => (f.source === d.name || f.target === d.name) ? "#c05621" : "#5a6a85");
      dot.attr("opacity", c => near.has(c.name) ? 1 : 0.2);
      lab.attr("opacity", c => near.has(c.name) ? 1 : 0.2);
    })
    .on("mousemove", (event, d) => {
      const s = stats.get(d.name);
      showTip(event, `<b>${d.name}</b><br>Population: ${fmt(d.pop)}<br>` +
        (s ? `${s.routes} routes, ${s.flights} flights per week${isHub(d) ? "<br>Hub" : ""}` : "No routes in dataset"));
    })
    .on("mouseout", () => {
      route.attr("stroke-opacity", 0.5).attr("stroke", "#5a6a85");
      dot.attr("opacity", 1); lab.attr("opacity", 1); hideTip();
    });

  // legend explaining all four encodings
  const L = d3.select("#combined-legend").append("svg").attr("viewBox", "0 0 250 420");
  const row = (y, title) => L.append("text").attr("x", 0).attr("y", y).attr("font-size", 13).attr("font-weight", 700).text(title);

  row(16, "Position");
  L.append("text").attr("x", 0).attr("y", 34).attr("font-size", 12).attr("fill", "#616e7c").text("Location on the map = real");
  L.append("text").attr("x", 0).attr("y", 49).attr("font-size", 12).attr("fill", "#616e7c").text("city coordinates");

  row(92, "Circle size = population");
  [1e6, 5e6, 15e6].forEach((v, i) => {
    const cx = 36 + i * 80;
    L.append("circle").attr("cx", cx).attr("cy", 150 - r(v)).attr("r", r(v)).attr("fill", "none").attr("stroke", "#444");
    L.append("text").attr("x", cx).attr("y", 166).attr("text-anchor", "middle").attr("font-size", 11).text(`${v / 1e6} M`);
  });

  row(204, "Color = hub status");
  [["#d9480f", `Hub (${HUB_MIN}+ routes)`], ["#2b6cb0", `Not a hub (< ${HUB_MIN} routes)`]].forEach(([c, t], i) => {
    L.append("circle").attr("cx", 10).attr("cy", 224 + i * 24).attr("r", 7).attr("fill", c).attr("fill-opacity", 0.7);
    L.append("text").attr("x", 26).attr("y", 228 + i * 24).attr("font-size", 12).text(t);
  });

  row(292, "Line width = flights / week");
  const samples = [2, 14, 42];
  samples.forEach((v, i) => {
    L.append("line").attr("x1", 0).attr("x2", 56).attr("y1", 314 + i * 26).attr("y2", 314 + i * 26)
      .attr("stroke", "#5a6a85").attr("stroke-opacity", 0.7).attr("stroke-linecap", "round").attr("stroke-width", lw(v));
    L.append("text").attr("x", 68).attr("y", 318 + i * 26).attr("font-size", 12).text(`${v} flights`);
  });
}

/* ---------- run everything; one failing task should not stop the others ---------- */
[
  ["#treemap", drawTreemap], ["#dendrogram", drawDendrogram], ["#network", drawNetwork],
  ["#choropleth", drawChoropleth], ["#pointmap", drawPointMap], ["#combined", drawCombined]
].forEach(([sel, fn]) => {
  fn().catch(err => {
    console.error(fn.name, err);
    d3.select(sel).append("div").attr("class", "error")
      .text(`Could not draw this chart: ${err.message}. Open the page through a local server (e.g. VS Code Live Server).`);
  });
});
