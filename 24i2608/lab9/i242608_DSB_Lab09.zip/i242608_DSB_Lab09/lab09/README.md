# Lab 9 – Hierarchies, Networks and Maps (D3.js)

Open `index.html` through a local server (e.g. VS Code Live Server). Do not double-click the file: `d3.csv` and `d3.json` cannot load files from `file://`.

- `index.html`, `script.js` – all six tasks (one section per task)
- `lib/d3.min.js` – D3 v7, bundled so the page also works offline
- `dataset/` – `university.csv`, `flights.csv`, `population.csv`, `pakistan_cities.csv`, `world.geojson`

The CSV files contain sample data in the column format given in the manual. Replace them with the official lab files (same names, same folder) and the charts update without code changes.
